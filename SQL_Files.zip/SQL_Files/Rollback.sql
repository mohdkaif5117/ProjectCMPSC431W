-- Begin Transaction
BEGIN;

-- Step 1: Check Book Availability
DECLARE available BOOLEAN;
SELECT Availability INTO available FROM Book WHERE BookID = 1 FOR UPDATE;

-- If the book is not available, rollback the transaction
IF NOT available THEN
    ROLLBACK;
    RAISE EXCEPTION 'The selected book is not available for borrowing.';
END IF;

-- Step 2: Record the Borrowing Transaction
INSERT INTO "Transaction" (UserID, BookID, BorrowDate)
VALUES (1, 1, CURRENT_DATE);

-- Step 3: Update Book Availability
UPDATE Book SET Availability = FALSE WHERE BookID = 1;

-- Commit the transaction
COMMIT;
