CREATE TABLE Transaction (
  TransactionID INT PRIMARY KEY,
  UserID INT,
  BookID INT,
  BorrowDate DATE,
  ReturnDate DATE,
  FOREIGN KEY (UserID) REFERENCES "User"(UserID),
  FOREIGN KEY (BookID) REFERENCES Book(BookID)
);