-- Analytical Report: Average Ratings of Books, Sorted by Rating in Descending Order
SELECT
    B.Title AS BookTitle,
    AVG(R.Rating) AS AverageRating
FROM
    Book B
LEFT JOIN
    Review R ON B.BookID = R.BookID
GROUP BY
    B.BookID, B.Title
ORDER BY
    AverageRating DESC;
