CREATE TABLE Book (
  BookID INT PRIMARY KEY,
  Title VARCHAR(255),
  AuthorID INT,
  GenreID INT,
  ISBN VARCHAR(20) UNIQUE,
  PublishedYear INT,
  Available BOOLEAN,
  FOREIGN KEY (AuthorID) REFERENCES Author(AuthorID),
  FOREIGN KEY (GenreID) REFERENCES Genre(GenreID)
);