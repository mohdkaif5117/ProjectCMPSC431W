-- Insert data into "Wishlist" table
INSERT INTO Wishlist (WishlistID, UserID, BookID)
VALUES
(1, 1, 2),
(2, 1, 5),
(3, 2, 1),
(4, 3, 3),
(5, 3, 6),
(6, 4, 4),
(7, 5, 7),
(8, 5, 10),
(9, 6, 9),
(10, 7, 8);

-- Add more wishlist entries as needed
