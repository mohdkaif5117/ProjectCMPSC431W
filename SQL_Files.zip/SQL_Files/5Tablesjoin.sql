-- Question: Retrieve information about books borrowed by a specific user, including details about the author and genre.
SELECT
    U.FirstName || ' ' || U.LastName AS UserName,
    B.Title AS BookTitle,
    A.FirstName || ' ' || A.LastName AS AuthorName,
    G.GenreName
FROM
    "User" U
JOIN
    Transaction T ON U.UserID = T.UserID
JOIN
    Book B ON T.BookID = B.BookID
JOIN
    Author A ON B.AuthorID = A.AuthorID
JOIN
    Genre G ON B.GenreID = G.GenreID
WHERE
    U.UserID = 1; -- Replace with the desired user ID
