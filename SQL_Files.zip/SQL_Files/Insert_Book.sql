-- Insert data into "Transaction" table
INSERT INTO Transaction (TransactionID, UserID, BookID, BorrowDate, ReturnDate)
VALUES
(1, 1, 1, '2023-01-01', '2023-01-15'),
(2, 2, 2, '2023-02-01', '2023-02-15'),
(3, 3, 3, '2023-03-01', '2023-03-15'),
-- Add more transactions as needed

-- Continue with other previously inserted User and Book combinations
(4, 4, 4, '2023-04-01', '2023-04-15'),
(5, 5, 5, '2023-05-01', '2023-05-15'),
(6, 6, 6, '2023-06-01', '2023-06-15');
-- Add more transactions as needed

-- Ensure that UserIDs and BookIDs exist in the corresponding tables
