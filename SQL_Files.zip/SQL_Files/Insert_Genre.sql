-- Insert data into "Genre" table
INSERT INTO Genre (GenreID, GenreName)
VALUES
(1, 'Fiction'),
(2, 'Classics'),
(3, 'Dystopian'),
(4, 'Romance'),
(5, 'Coming of Age'),
(6, 'ComicFantasy'),
(7, 'Adventure'),
(8, 'Science Fiction'),
(9, 'Philosophy'),
(10, 'Magical Realism'),
(11, 'Mystery'),
(12, 'Gothic'),
(13, 'Epic Poetry'),
(14, 'Allegory'),
(15, 'Satire1'),
(16, 'Tragedy'),
(17, 'Historical Fiction'),
(18, 'Satire2'),
(19, 'Philosophical'),
(20, 'Fantasy');
