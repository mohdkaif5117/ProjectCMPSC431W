-- Insert data into "User" table
INSERT INTO "User" (UserID, FirstName, LastName, Email, PhoneNumber, Address)
VALUES
(1, 'John', 'Doe', 'john.doe@email.com', '123-456-7890', '123 Main St'),
(2, 'Alice', 'Smith', 'alice.smith@email.com', '987-654-3210', '456 Oak St'),
(3, 'Robert', 'Johnson', 'robert.j@email.com', '555-123-7890', '789 Pine St'),
(4, 'Sophia', 'Williams', 'sophia.w@email.com', '111-222-3333', '321 Elm St'),
(5, 'Michael', 'Brown', 'michael.b@email.com', '444-555-6666', '567 Birch St'),
(6, 'Emily', 'Jones', 'emily.j@email.com', '777-888-9999', '890 Cedar St'),
(7, 'Daniel', 'Davis', 'daniel.d@email.com', '333-222-1111', '234 Maple St'),
(8, 'Emma', 'Taylor', 'emma.t@email.com', '999-888-7777', '432 Willow St'),
(9, 'Matthew', 'Miller', 'matthew.m@email.com', '666-555-4444', '678 Pine St'),
(10, 'Olivia', 'Anderson', 'olivia.a@email.com', '000-111-2222', '876 Oak St'),
(11, 'Ethan', 'Thomas', 'ethan.t@email.com', '555-666-7777', '987 Birch St'),
(12, 'Ava', 'White', 'ava.w@email.com', '111-222-3333', '765 Maple St'),
(13, 'Noah', 'Harris', 'noah.h@email.com', '444-555-6666', '543 Cedar St'),
(14, 'Isabella', 'Smith', 'isabella.s@email.com', '777-888-9999', '234 Elm St'),
(15, 'Liam', 'Johnson', 'liam.j@email.com', '999-888-7777', '876 Willow St'),
(16, 'Mia', 'Taylor', 'mia.t@email.com', '333-222-1111', '321 Pine St'),
(17, 'Jackson', 'Williams', 'jackson.w@email.com', '111-222-3333', '567 Cedar St'),
(18, 'Sophie', 'Brown', 'sophie.b@email.com', '555-666-7777', '890 Birch St'),
(19, 'Lucas', 'Thomas', 'lucas.t@email.com', '777-888-9999', '432 Maple St'),
(20, 'Chloe', 'Anderson', 'chloe.a@email.com', '999-888-7777', '765 Willow St');
