-- Insert data into "Fine" table with valid TransactionID values
INSERT INTO Fine (FineID, TransactionID, Amount, Paid)
VALUES
(1, 1, 5.00, true),
(2, 2, 8.50, false),
(3, 3, 3.75, true),
(4, 4, 6.20, false),
(5, 5, 10.00, true),
(6, 6, 2.50, false),
-- Ensure that the following TransactionID values exist in the Transaction table
(7, 1, 7.80, true),
(8, 2, 4.25, false),
(9, 3, 6.50, true),
(10, 4, 9.00, false);
