CREATE TABLE Fine (
  FineID INT PRIMARY KEY,
  TransactionID INT,
  Amount DECIMAL(10, 2),
  Paid BOOLEAN,
  FOREIGN KEY (TransactionID) REFERENCES Transaction(TransactionID)
);
