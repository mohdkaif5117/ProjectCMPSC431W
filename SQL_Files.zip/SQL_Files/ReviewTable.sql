CREATE TABLE Review (
  ReviewID INT PRIMARY KEY,
  UserID INT,
  BookID INT,
  Rating INT,
  Comment TEXT,
  FOREIGN KEY (UserID) REFERENCES "User"(UserID),
  FOREIGN KEY (BookID) REFERENCES Book(BookID)
);
