-- Insert data into "Author" table
INSERT INTO Author (AuthorID, FirstName, LastName)
VALUES
(1, 'F. Scott', 'Fitzgerald'),
(2, 'Harper', 'Lee'),
(3, 'George', 'Orwell'),
(4, 'Jane', 'Austen'),
(5, 'J.D.', 'Salinger'),
(6, 'J.K.', 'Rowling'),
(7, 'J.R.R.', 'Tolkien'),
(8, 'Aldous', 'Huxley'),
(9, 'Fyodor', 'Dostoevsky'),
(10, 'Gabriel', 'García Márquez'),
(11, 'Charles', 'Dickens'),
(12, 'Herman', 'Melville'),
(13, 'Homer', ''),
(14, 'Dante', 'Alighieri'),
(15, 'Oscar', 'Wilde'),
(16, 'Emily', 'Brontë'),
(17, 'Leo', 'Tolstoy'),
(18, 'Oscar', 'Wilde'),
(19, 'Leo', 'Tolstoy'),
(20, 'C.S.', 'Lewis');
