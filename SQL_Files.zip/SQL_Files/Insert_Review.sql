-- Insert data into "Review" table
INSERT INTO Review (ReviewID, UserID, BookID, Rating, Comment)
VALUES
(1, 1, 1, 5, 'Great book! Highly recommended.'),
(2, 2, 2, 4, 'Enjoyed the plot twists.'),
(3, 3, 3, 3, 'Average read, could be better.'),
(4, 4, 4, 5, 'Captivating storyline.'),
(5, 5, 5, 2, 'Not my favorite, but okay.'),
(6, 6, 6, 4, 'Well-written and engaging.'),
-- Add more reviews as needed

-- Continue with other previously inserted User and Book combinations
(7, 1, 2, 4, 'Liked the character development.'),
(8, 2, 3, 5, 'Couldnot put it down!'),
(9, 3, 4, 3, 'Expected more from the ending.'),
(10, 4, 5, 4, 'Excellent choice for book clubs.'),
(11, 5, 6, 2, 'Found it a bit slow-paced.'),
(12, 6, 1, 5, 'One of my all-time favorites.');
-- Add more reviews as needed

-- Ensure that UserIDs and BookIDs exist in the corresponding tables
